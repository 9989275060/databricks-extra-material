# Databricks notebook source
# MAGIC %run ../../Includes/Classroom-Setup-09.2.2L

# COMMAND ----------

DA.data_factory.load()

