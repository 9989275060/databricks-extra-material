# Databricks notebook source
# MAGIC %run ./_common

# COMMAND ----------

lesson_config.name = "jobs_demo_91"

DA = DBAcademyHelper(course_config, lesson_config)
# DA.reset_lesson()  # We don't want to reset the environment
DA.init()
DA.conclude_setup()

